﻿namespace Angular4DotNetMvc.Models.Registration
{
    public class RegistrationVm
    {
        public string Courses { get; set; }
        public string Instructors { get; set; }
    }
}