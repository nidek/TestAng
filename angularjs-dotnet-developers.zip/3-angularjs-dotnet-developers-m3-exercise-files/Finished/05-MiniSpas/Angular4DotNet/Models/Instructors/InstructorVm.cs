﻿namespace Angular4DotNetMvc.Models.Instructors
{
    public class InstructorVm
    {
        public string Name { get; set; }
        public string Email { get; set; }
        public int RoomNumber { get; set; }
    }

}