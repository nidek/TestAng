﻿namespace Angular4DotNetMvc.Models.Courses
{
    public class CourseVm
    {
        public string Number { get; set; }
        public string Name { get; set; }
        public string Instructor { get; set; }
    }
}